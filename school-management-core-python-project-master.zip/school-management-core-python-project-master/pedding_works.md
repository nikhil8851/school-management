## Pending work on School Management System

1. Choose_class fucniton ke bad me jaise hi new class create hua then again new choose_class fucntion ko show karna hai. Taki admin ayse hi aur classes bana sake ek bar me hi.
1. student_options_in_class is fucntion ke andar hum admin ko multipal options show karenge.
1. How to validate roll number when registering new student
1. new student registration ke bad fir se student roll number mang raha hai. isko kaise solve karen?
1. New registration hone ke bad success message dikhane ke bad kaise dubara ek class se realated option show karaya.
1. ab ek class ke existing sudent ka data roll number ke behalf par kaise dikhaye.
1. ek student ki detail dekhne ke bad dubara ek class ke baki option kaise dikhayen.
1. ab ek class ke student ki koi detial change ya update karni hai kaise karen?
1. last me kaise kisi bhi student ko delete kare behalf of roll number
